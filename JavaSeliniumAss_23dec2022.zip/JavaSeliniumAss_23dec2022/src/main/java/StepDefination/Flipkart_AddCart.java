//package StepDefination;
//
//import java.util.concurrent.TimeUnit;
//
//import org.openqa.selenium.By;
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.chrome.ChromeDriver;
//
//import io.cucumber.java.en.*;
//import io.cucumber.java.en.Then;
//import io.cucumber.java.en.When;
//
//public class Flipkart_AddCart {
//
//	WebDriver driver = null;
//
//	@Given("a browser is open on screen")
//	public void browser_is_open() {
//		// Write code here that turns the phrase above into concrete actions
//		System.out.println("inside Step- browser is open on screen");
//		String projectPath= System.getProperty("user.dir");
//		
//		System.out.println("Project path is: " +projectPath);
//		
//		System.setProperty("webdriver.chrome.driver",projectPath+"/src/main/resources/Drivers/chromedriver.exe");
//	driver = new ChromeDriver();
//	driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
//	driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//	//driver.manage().window().maximize();
//	
//	}
//	
//	@When("user is on a Flipkart site page")
//	public void user_is_on_flipkart_site_page() {
//		System.out.println("inside Step- a user is on Flipkart site page");
//     	driver.navigate().to("https://www.flipkart.com/");
//	}
//	
//	@And("A Click on cart icon")
//	public void a_click_on_cart_icon() {
//		System.out.println("inside Step- A Click on cart icon");
//		driver.findElement (By.className ("V3C5bO")).click();
//	}
//
//	
//
//	@And("User search for Samsung Mobiles")
//	public void user_search_for_samsung_mobiles(io.cucumber.datatable.DataTable dataTable) {
//		System.out.println("inside Step- User search for Samsung Mobiles");
//		driver.findElement(By.name("q")).sendKeys ("Samsung Mobiles");
//	}
//
//	
//
//	@When("Add the Mobile that appears in the search result to the basket")
//	public void add_the_mobile_that_appears_in_the_search_result_to_the_basket() {
//		System.out.println("inside Step- Add the Mobile that appears in the search result to the basket");
//		driver.findElement (By.className ("_4rR01T")).click();
//	}
//
//	@When("User basket should display with added item")
//	public void user_basket_should_display_with_added_item() {
//		System.out.println("inside Step- User basket should display with added item");
//		driver.findElement (By.className ("class=\"_2KpZ6l _2U9uOA _3v1-ww")).click();
//	}
//
//	@Then("Added item should be displayed in the cart")
//	public void added_item_should_be_displayed_in_the_cart() {
//		System.out.println("inside Step- Added item should be displayed in the cart");
//	}
//
//	
//	
//}
//
//
//
